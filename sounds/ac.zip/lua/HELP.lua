
-- [ERROR] addons/atlaschat/lua/atlaschat/gui/slider.lua:24: attempt to call method 'SetMin' (a nil value)
-- 1. Init - addons/atlaschat/lua/atlaschat/gui/slider.lua:24
--   3. ParseConfig - addons/atlaschat/lua/atlaschat/themes/default.lua:512
--    4. callback - addons/atlaschat/lua/atlaschat/themes/default.lua:713
    -- 5. Call - addons/atlaschat/lua/atlaschat/cl_theme.lua:101
    --  6. callback - addons/atlaschat/lua/atlaschat/themes/default.lua:168
    --   7. DoClick - addons/atlaschat/lua/atlaschat/cl_panel.lua:93